package com.cg.ab;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;




public class Client {

	public static void main(String[] args) {
		
		int bookId;
		String authorName;
		String title;
		double price;
		
		Scanner scInput = new Scanner(System.in);
		
		
		while(true){
			
			
			System.out.println("\n1. Query All books in DataBase");
			System.out.println("2. Query All books written by given Author name");
			System.out.println("3. List All books with given price range i.e Rs 500 to 1000");
			System.out.println("4. List the Author name for given book id\n");
			
			int choice = scInput.nextInt();
			scInput.nextLine();
			
			EntityManagerFactory factory = Persistence
					.createEntityManagerFactory("JPA-PU");
			EntityManager em = factory.createEntityManager();
			em.getTransaction().begin();
			
			switch(choice){
				case 1:
					
					Author auth1 = new Author();
					auth1.setName("Jatin");

					Author auth2 = new Author();
					auth2.setName("Abhi");

					Author auth3 = new Author();
					auth3.setName("Squirell");

					// now define first order and add few products in it
					Book book1 = new Book();
					book1.setPrice(10000);
					book1.setTitle("Java Programming");

					book1.addAuthor(auth1);
					book1.addAuthor(auth2);

					// now define second order and add few products in it
					Book book2 = new Book();
					book2.setPrice(500);
					book2.setTitle("SQL");

					book2.addAuthor(auth1);
					book2.addAuthor(auth3);
					
					// save orders using entity manager

					em.persist(book1);
					em.persist(book2);
					
					System.out.println("Added books along with book details to database.");

					em.getTransaction().commit();
					em.close();
					factory.close();
					
					break;
					
				case 2:
					
					System.out.println("Enter the Author Name : ");
					authorName = scInput.nextLine();
					
					Author auth = null;
					try {
						TypedQuery<Author> qry = em.createQuery("from Author where name=:authname",Author.class);
						
						qry.setParameter("authname",authorName);
						
						auth = qry.getSingleResult();
						
					
								System.out.println("Author Name : " + auth.getName());
								Set<Book> booklists = auth.getBooks();
								System.out.print("Book Title : ");
								for(Book booklist: booklists){
									System.out.print(booklist.getTitle()+",");
								}
						em.getTransaction().commit();
						em.close();
						factory.close();
						
					} catch (Exception e) {
						System.out.println("No author found");
					}
					break;
					
				case 3:
					
					System.out.println("List of books between 500 and 1000");
					try {
						TypedQuery<Book> qry = em.createQuery("from Book where price Between 600 AND 1000",Book.class);

						
						List<Book> list = qry.getResultList();
						
						if(list.isEmpty())
						{
							System.out.println("No records found");
						}else{
							
							for(Book booklist : list){
								System.out.println(booklist.getTitle()+",");	
							}
							em.getTransaction().commit();
							em.close();
							factory.close();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
						
					break;
					
				case 4:
					
					System.out.println("Enter the Book ID : ");
					bookId = scInput.nextInt();
					scInput.nextLine();
					
					Book book;
					try {
						TypedQuery<Book> qry = em.createQuery("from Book where id=:bookid",Book.class);
						
						qry.setParameter("bookid",bookId);
						
						book = qry.getSingleResult();
						
					
								System.out.println("Book Name : " + book.getTitle());
								Set<Author> authorlists = book.getAuthors();
								System.out.print("Author Names : ");
								for(Author authorlist: authorlists){
									System.out.print(authorlist.getName()+",");
								}
						em.getTransaction().commit();
						em.close();
						factory.close();
						
					} catch (Exception e) {
						System.out.println("No book found");
					}
					
					break;
					
				default :
					
					break;
					
			}
		}
	}

}
