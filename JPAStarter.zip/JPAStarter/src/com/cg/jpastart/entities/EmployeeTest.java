package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


public class EmployeeTest {

	public static void main(String[] args) 
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
		TypedQuery<Employee> qry = em.createNamedQuery("viewAllEmployee", Employee.class);
		
		List<Employee> list=qry.getResultList();
		for( Employee emp: list)
		
		System.out.println(emp.getEmployeeId()+""+emp.getEmployeeName()+""+emp.getEmployeeSalary());
		
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}

}
