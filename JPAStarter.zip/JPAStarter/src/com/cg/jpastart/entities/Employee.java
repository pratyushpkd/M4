package com.cg.jpastart.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Entity
@Table(name="employee_tbl")
@NamedQuery(name="ViewAllEmployee",query="from Employee")
public class Employee 
{
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		@Column(name="emp_id")
		private int employeeId;
		
		@Column(name="emp_name", length=15)
		private String employeeName;
		
		@Column(name="emp_salary")
		private int employeeSalary;
		
		public Employee() 
		{
			super();
		}

		public Employee(int employeeId, String employeeName, int employeeSalary) {
			super();
			this.employeeId = employeeId;
			this.employeeName = employeeName;
			this.employeeSalary = employeeSalary;
		}

		public int getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}

		public String getEmployeeName() {
			return employeeName;
		}

		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}

		public int getEmployeeSalary() {
			return employeeSalary;
		}

		public void setEmployeeSalary(int employeeSalary) {
			this.employeeSalary = employeeSalary;
		}
		
}
