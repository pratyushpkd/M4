package com.cg.jpaauthor.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="author")
public class Author 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="author_id")
	private int authorId;
	
	@Column(name="author_fname", length=32)
	private String firstname;
	
	@Column(name="author_mname", length=32)
	private String middleName;
	
	@Column(name="author_lname", length=32)
	private String lastName;
	
	@Column(name="mobile_number")
	private int mobileNumber; 
	
	public Author() {
		super();
	}

	public Author(int authorId, String firstname, String middleName,
			String lastName, int mobileNumber) {
		super();
		this.authorId = authorId;
		this.firstname = firstname;
		this.middleName = middleName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
	}

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(int mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

}
