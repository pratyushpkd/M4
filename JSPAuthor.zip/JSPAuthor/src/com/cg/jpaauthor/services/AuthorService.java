package com.cg.jpaauthor.services;

import com.cg.jpaauthor.entities.Author;

public interface AuthorService 
{
	public abstract void addStudent(Author author);

	public abstract void deleteStudent(int id);

	public abstract void findStudentById(int id);

}
