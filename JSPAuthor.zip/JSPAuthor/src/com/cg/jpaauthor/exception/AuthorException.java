package com.cg.jpaauthor.exception;

public class AuthorException extends Exception
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7264235506700683512L;

	public AuthorException()
	{
		super();
	}
	
	public AuthorException(String message)
	{
		super(message);
	}
	
}
