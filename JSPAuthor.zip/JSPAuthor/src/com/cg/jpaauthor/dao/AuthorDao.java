package com.cg.jpaauthor.dao;

import java.util.List;

import com.cg.jpaauthor.entities.Author;
import com.cg.jpaauthor.exception.AuthorException;

public interface AuthorDao
{
	public int addAuthor(Author author) throws AuthorException;
	
	public Author deleteAuthor(int id) throws AuthorException;
	
	public Author findAuthor(int id) throws AuthorException;
	
	public List<Author> viewAllAuthor() throws AuthorException;
	
}
