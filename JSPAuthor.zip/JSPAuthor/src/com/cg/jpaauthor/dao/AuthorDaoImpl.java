package com.cg.jpaauthor.dao;

import java.util.List;

import javax.persistence.EntityManager;

import com.cg.jpaauthor.entities.Author;
import com.cg.jpaauthor.exception.AuthorException;

public class AuthorDaoImpl implements AuthorDao {

	private EntityManager entityManager;

	public AuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public int addAuthor(Author author) throws AuthorException {
		entityManager.persist(author);
		return 0;
	}

	@Override
	public Author deleteAuthor(int id) throws AuthorException {
		entityManager.remove(author);
		return null;
	}

	@Override
	public Author findAuthor(int id) throws AuthorException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Author> viewAllAuthor() throws AuthorException {
		// TODO Auto-generated method stub
		return null;
	}

}
