package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Client1
{
public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
	
		String qryStr="from Employee where depatment.id=10";
		
		TypedQuery<Employee> query = em.createQuery();
		
		List<Employee> list = query.getResultList();
		
		for(Employee emp: list)
		{
			System.out.println(emp.getName());
		}
		
		
		em.getTransaction().commit();
		em.close();
		factory.close();
	}
}
