package com.cg.crud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.crud.bean.Author;
import com.cg.crud.exception.AuthorException;

public class AuthorDAOImpl implements IAuthorDAO {

	private EntityManager entityManager;
	private EntityManagerFactory factory; 
	
	
	public AuthorDAOImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public int addAuthor(Author author) throws AuthorException {
		
		
		entityManager.persist(author);
		int id = author.getAuthorId();
		return id;
	}

	@Override
	public Author deleteAuthor(int id) throws AuthorException {
		
		Author author = entityManager.find(Author.class, id);
		
		if(author==null){
			System.out.println("Author not found");
		}else{
			
			entityManager.remove(author);
			System.out.println(author+"\nAuthor removed successfully");
		}
		
		return author;
	}

	@Override
	public Author findAuthor(int id) throws AuthorException {
		
		Author author = entityManager.find(Author.class, id);
		
		return author;
	}

	@Override
	public List<Author> viewAllAuhtor() throws AuthorException {
		
		TypedQuery<Author> qry = entityManager.createQuery("from Author",Author.class);
		
		List<Author> list = qry.getResultList();
		
		return list;
	}
	
	@Override
	public Author updateAuthor(int id,  String mobileNo) throws AuthorException {
		
		Author author = entityManager.find(Author.class, id);
		
		if(author!=null){
			
			author.setMobileNo(mobileNo);
			
			entityManager.merge(author); //without merge update function still works
		}
		return author;
	}

	@Override
	public void beginTransaction() throws AuthorException {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() throws AuthorException {
		entityManager.getTransaction().commit();
	}

	

}
