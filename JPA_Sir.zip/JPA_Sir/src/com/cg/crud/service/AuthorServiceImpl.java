package com.cg.crud.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.crud.bean.Author;
import com.cg.crud.dao.AuthorDAOImpl;
import com.cg.crud.dao.IAuthorDAO;
import com.cg.crud.exception.AuthorException;

public class AuthorServiceImpl implements IAuthorService {

	private EntityManager entityManager;
	private EntityManagerFactory factory;
	private IAuthorDAO authorDao;
	
	public AuthorServiceImpl() {
		authorDao = new AuthorDAOImpl();
	}
	
	@Override
	public int addAuthor(Author author) throws AuthorException {

		authorDao.beginTransaction();
		int id = authorDao.addAuthor(author);
		authorDao.commitTransaction();
		
		return id;
	}

	@Override
	public Author deleteAuthor(int id) throws AuthorException {
		
		authorDao.beginTransaction();
		Author author = authorDao.deleteAuthor(id);
		authorDao.commitTransaction();
		
		return author;
		
	}

	@Override
	public Author findAuthor(int id) throws AuthorException {

		authorDao.beginTransaction();
		Author author = authorDao.findAuthor(id);
		authorDao.commitTransaction();
		
		return author;
		
	}

	@Override
	public List<Author> viewAllAuhtor() throws AuthorException {

		authorDao.beginTransaction();
		List<Author> list= authorDao.viewAllAuhtor();
		authorDao.commitTransaction();
		
		return list;
	}

	@Override
	public Author updateAuthor(int id, String mobileNo) throws AuthorException {
		
		authorDao.beginTransaction();
		Author author = authorDao.updateAuthor(id, mobileNo);
		authorDao.commitTransaction();
		return author;
	}
	
	

}
