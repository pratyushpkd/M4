package com.cg.crud.service;

import java.util.List;

import com.cg.crud.bean.Author;
import com.cg.crud.exception.AuthorException;

public interface IAuthorService {

	
	public int addAuthor(Author author) throws AuthorException;
	
	public Author deleteAuthor(int id) throws AuthorException;
	
	public Author findAuthor(int id) throws AuthorException;
	
	public List<Author> viewAllAuhtor() throws AuthorException;
	
	public Author updateAuthor(int id,  String mobileNo) throws AuthorException;
}
