package com.cg.jpastart.author;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		
		Book b1=new Book();
		b1.setBook_ISBN(501);
		b1.setTitle("maths");
		b1.setPrice(700);
		
		
		Book b2=new Book();
		b2.setBook_ISBN(502);
		b2.setTitle("eng");
		b2.setPrice(500);
		
		
		Book b3=new Book();
		b3.setBook_ISBN(503);
		b3.setTitle("beng");
		b3.setPrice(200);
		
		
		Book b4=new Book();
		b4.setBook_ISBN(504);
		b4.setTitle("science");
		b4.setPrice(900);
		
		Author a1=new Author();
		a1.setId(1);
		a1.setAuthorName("abc");
		
		Author a2=new Author();
		a2.setId(2);
		a2.setAuthorName("xyz");
		
		Author a3=new Author();
		a3.setId(3);
		a3.setAuthorName("pqr");
		
		a1.addBooks(b1);
		a1.addBooks(b3);
		
		a2.addBooks(b4);
		a2.addBooks(b1);
		a2.addBooks(b2);
		
		a3.addBooks(b1);
		a3.addBooks(b4);
		
		
		em.persist(a1);
		em.persist(a2);
		em.persist(a3);
		
		System.out.println("Data inserted Successfully");
		
		
		
		
		em.getTransaction().commit();
		em.close();
		factory.close();

	}

}
