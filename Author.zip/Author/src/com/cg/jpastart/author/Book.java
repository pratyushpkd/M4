package com.cg.jpastart.author;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="book_mtr")

public class Book {
		
	@Id
	@Column(name="ISBN",length=10)
	 private int book_ISBN;
	 
	@Column(name="TItle",length=10)
	 private String title;
	 
	@Column(name="Price",length=10)
	 private int price;
	
	@ManyToMany(fetch=FetchType.EAGER,mappedBy="books")
	private Set<Author> authors = new HashSet<>();

	public int getBook_ISBN() {
		return book_ISBN;
	}

	public void setBook_ISBN(int book_ISBN) {
		this.book_ISBN = book_ISBN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}
