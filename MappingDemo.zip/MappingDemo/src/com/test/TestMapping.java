package com.test;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class TestMapping {

	public static void main(String[] args) 
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
		
		Query qry=em.createQuery(qryStr);
		String qryStr="from Employee where department.departmentId>1";
		
		
		List<Employee> list =qry.getResultList();
		for (Employee employee : list)
		{
			System.out.println(employee.getEmployeeName());
		}
		
		
		
		
		em.getTransaction().commit();
		System.out.println("Employee Info");
		em.close();
		emf.close();
	}
}
